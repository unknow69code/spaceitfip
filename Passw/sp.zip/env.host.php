<?php exit; ?>
BASE_DE_DATOS_MYSQL = 'u358278316_space_db'
USUARIO_MYSQL       = 'u358278316_space_inc'
CLAVE_MYSQL         = 'Space_pass31'
SERVIDOR_MYSQL      = '127.0.0.1:3306'
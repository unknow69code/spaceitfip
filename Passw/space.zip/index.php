<?php

header('Location: login.php?iniciar_sesion');
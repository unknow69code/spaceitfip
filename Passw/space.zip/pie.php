</div>
<div class="container">
	<footer class="py-3 my-4 border-bottom pb-3 mb-3">
		<p class="text-center text-muted">&copy; 2022, Software para pr&eacute;stamo y retiros de elementos y/o espacios f&iacute;sicos del ITFIP</p>
	</footer>
</div>
</body>
</html>

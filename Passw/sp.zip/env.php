<?php exit; ?>
BASE_DE_DATOS_MYSQL = 'u361342399_spaceitfip_db'
USUARIO_MYSQL       = 'maurengomez'
CLAVE_MYSQL         = 'admin'
SERVIDOR_MYSQL      = '127.0.0.1:3306'
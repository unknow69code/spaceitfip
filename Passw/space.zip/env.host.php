<?php exit; ?>
BASE_DE_DATOS_MYSQL = 'u361342399_spaceitfip_db'
USUARIO_MYSQL       = 'u361342399_maurengomez'
CLAVE_MYSQL         = 'Mausuga9712'
SERVIDOR_MYSQL      = '127.0.0.1:3306'